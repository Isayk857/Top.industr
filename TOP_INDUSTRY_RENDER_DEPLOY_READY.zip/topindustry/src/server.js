import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const { Pool } = pg;
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes("localhost") ? false : { rejectUnauthorized: false } });

app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(express.json());
const __filename=fileURLToPath(import.meta.url); const __dirname=path.dirname(__filename);

function token(user) {
  return jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });
}
function auth(req,res,next){
  try {
    const h = req.headers.authorization || "";
    if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Login required"});
    req.user = jwt.verify(h.slice(7), process.env.JWT_SECRET);
    next();
  } catch { res.status(401).json({error:"Invalid or expired token"}); }
}
function admin(req,res,next){ if(req.user.role !== "admin") return res.status(403).json({error:"Admin only"}); next(); }


async function initDatabase(){
  if(!process.env.DATABASE_URL){
    console.warn("DATABASE_URL is not set; database-backed features will not work until it is configured.");
    return;
  }
  const schemaPath = path.join(__dirname,"../schema.sql");
  const schema = await (await import("fs/promises")).readFile(schemaPath,"utf8");
  await pool.query(schema);
  console.log("Database schema ready.");
}

app.get("/api/health", (req,res)=>res.json({ok:true, service:"TOP INDUSTRY"}));
app.use(express.static(path.join(__dirname,"../public")));
app.get("/",(req,res)=>res.sendFile(path.join(__dirname,"../public/index.html")));

app.post("/api/auth/register", async (req,res)=>{
  try{
    const {name,email,phone,password}=req.body;
    if(!name || !email || !phone || !password || password.length < 6) return res.status(400).json({error:"Name, phone, email and password (6+ chars) are required"});
    const hash=await bcrypt.hash(password,12);
    const r=await pool.query("INSERT INTO users(name,email,phone,password_hash) VALUES($1,$2,$3,$4) RETURNING id,name,email,phone,role,balance",[name,email.toLowerCase(),phone,hash]);
    res.status(201).json({user:r.rows[0],token:token(r.rows[0])});
  }catch(e){
    if(e.code==="23505") return res.status(409).json({error:"Email or phone already registered"});
    console.error(e); res.status(500).json({error:"Server error"});
  }
});

app.post("/api/auth/login", async (req,res)=>{
  try{
    const {email,password}=req.body;
    const r=await pool.query("SELECT * FROM users WHERE email=$1",[String(email||"").toLowerCase()]);
    const u=r.rows[0];
    if(!u || !(await bcrypt.compare(password||"",u.password_hash))) return res.status(401).json({error:"Invalid email or password"});
    res.json({user:{id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role,balance:u.balance},token:token(u)});
  }catch(e){console.error(e);res.status(500).json({error:"Server error"});}
});

app.get("/api/me",auth,async(req,res)=>{
  const r=await pool.query("SELECT id,name,email,phone,role,balance,created_at FROM users WHERE id=$1",[req.user.id]);
  res.json(r.rows[0]||null);
});

app.get("/api/videos",async(req,res)=>{
  const r=await pool.query("SELECT id,title,description,video_url,thumbnail_url,created_at FROM videos WHERE is_active=true ORDER BY created_at DESC");
  res.json(r.rows);
});

app.post("/api/deposits",auth,async(req,res)=>{
  const {amount,method,transaction_reference}=req.body;
  const allowedMethods = ["Telebirr","Sinqee","Awash Bank"];
  if(!amount || Number(amount)<=0 || !method || !transaction_reference) return res.status(400).json({error:"Amount, method and transaction reference are required"});
  if(!allowedMethods.includes(method)) return res.status(400).json({error:"Unsupported deposit method"});
  const r=await pool.query("INSERT INTO deposit_requests(user_id,amount,method,transaction_reference) VALUES($1,$2,$3,$4) RETURNING *",[req.user.id,amount,method,transaction_reference]);
  res.status(201).json({message:"Deposit request submitted for admin verification",request:r.rows[0]});
});

app.get("/api/admin/deposits",auth,admin,async(req,res)=>{
  const r=await pool.query(`SELECT d.*,u.name,u.email FROM deposit_requests d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC`);
  res.json(r.rows);
});

app.post("/api/admin/deposits/:id/approve",auth,admin,async(req,res)=>{
  const client=await pool.connect();
  try{
    await client.query("BEGIN");
    const d=(await client.query("SELECT * FROM deposit_requests WHERE id=$1 FOR UPDATE",[req.params.id])).rows[0];
    if(!d || d.status!=="pending") { await client.query("ROLLBACK"); return res.status(400).json({error:"Request not found or already processed"}); }
    await client.query("UPDATE deposit_requests SET status='approved' WHERE id=$1",[d.id]);
    await client.query("UPDATE users SET balance=balance+$1 WHERE id=$2",[d.amount,d.user_id]);
    await client.query("INSERT INTO transactions(user_id,type,amount,reference) VALUES($1,'deposit', $2,$3)",[d.user_id,d.amount,d.transaction_reference]);
    await client.query("COMMIT");
    res.json({ok:true});
  }catch(e){await client.query("ROLLBACK");console.error(e);res.status(500).json({error:"Approval failed"});}
  finally{client.release();}
});

app.get("/api/admin/withdrawals",auth,admin,async(req,res)=>{
  const r=await pool.query(`SELECT w.*,u.name,u.email,u.phone FROM withdrawal_requests w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC`);
  res.json(r.rows);
});

app.post("/api/admin/withdrawals/:id/approve",auth,admin,async(req,res)=>{
  const client=await pool.connect();
  try{
    await client.query("BEGIN");
    const w=(await client.query("SELECT * FROM withdrawal_requests WHERE id=$1 FOR UPDATE",[req.params.id])).rows[0];
    if(!w || w.status!=="pending"){await client.query("ROLLBACK");return res.status(400).json({error:"Request not found or already processed"});}
    await client.query("UPDATE withdrawal_requests SET status='approved' WHERE id=$1",[w.id]);
    await client.query("COMMIT");
    res.json({ok:true});
  }catch(e){await client.query("ROLLBACK");console.error(e);res.status(500).json({error:"Approval failed"});}
  finally{client.release();}
});

app.post("/api/admin/videos",auth,admin,async(req,res)=>{
  const {title,description,video_url,thumbnail_url=""}=req.body;
  if(!title || !video_url) return res.status(400).json({error:"Title and video URL are required"});
  const r=await pool.query("INSERT INTO videos(title,description,video_url,thumbnail_url) VALUES($1,$2,$3,$4) RETURNING *",[title,description||"",video_url,thumbnail_url]);
  res.status(201).json(r.rows[0]);
});

app.delete("/api/admin/videos/:id",auth,admin,async(req,res)=>{
  await pool.query("UPDATE videos SET is_active=false WHERE id=$1",[req.params.id]);
  res.json({ok:true});
});

app.post("/api/withdrawals",auth,async(req,res)=>{
  const {amount,account}=req.body;
  if(!amount||Number(amount)<=0||!account)return res.status(400).json({error:"Amount and account/phone are required"});
  const client=await pool.connect();
  try{
    await client.query("BEGIN");
    const u=(await client.query("SELECT balance FROM users WHERE id=$1 FOR UPDATE",[req.user.id])).rows[0];
    if(!u||Number(u.balance)<Number(amount)){await client.query("ROLLBACK");return res.status(400).json({error:"Insufficient balance"});}
    await client.query("UPDATE users SET balance=balance-$1 WHERE id=$2",[amount,req.user.id]);
    const r=await client.query("INSERT INTO withdrawal_requests(user_id,amount,account) VALUES($1,$2,$3) RETURNING *",[req.user.id,amount,account]);
    await client.query("INSERT INTO transactions(user_id,type,amount,reference) VALUES($1,'withdrawal',$2,$3)",[req.user.id,amount,account]);
    await client.query("COMMIT");res.status(201).json({message:"Withdrawal request submitted",request:r.rows[0]});
  }catch(e){await client.query("ROLLBACK");console.error(e);res.status(500).json({error:"Withdrawal failed"});}finally{client.release();}
});

app.post("/api/payments/create",auth,async(req,res)=>{
  res.status(501).json({
    error:"Payment gateway is not configured yet.",
    next:"Select a supported Ethiopian payment provider and add its merchant/API credentials to .env. Do not put secret keys in frontend code."
  });
});

app.post("/api/payments/callback",async(req,res)=>{
  // Provider-specific webhook verification must be implemented here.
  res.json({received:true});
});

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Unexpected server error"});});
const port=Number(process.env.PORT||3000);
export { app };

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  app.listen(port,()=>console.log(`TOP INDUSTRY API running on port ${port}`));
}
